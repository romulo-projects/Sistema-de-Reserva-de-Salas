; <?php exit;?>

[login]
admin_user = "administrator"
admin_password = "da1907216877e31462c14b35db67de32"

[website]
seo_urls = "0"
currency = ""
date_format = "d/m/Y"
results_per_page = "10"
admin_email = "rlibera@siqueiracastro.com.br"
use_captcha_images = "0"

[email]
smtp_server = "localhost"
smtp_user = ""
smtp_password = ""
smtp_port = "25"

