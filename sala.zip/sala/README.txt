To install PHP Hotel Booking on your website, you just need
to unzip PHPHotelBooking.zip and copy the files to your preferred folder.

The administration panel will be available on - 

[your installation folder]/admin 

and the default username and password will be -

username: administrator
password: abc123

(after you log in, you can change them with different ones you may prefer)

So for example if you upload it on:

www.yourdomain.com/test

then the administration panel will be available on:

www.yourdomain.com/test/admin
username: administrator
password: abc123

Please note that you are required to keep the Powered By link at the bottom of the site.
If you prefer The Powered By link to be removed, this can be done for a $29 one-time fee (if you wish, we can also do then on request a free installation on your server / hosting package).

For any questions or suggestions, please don't hesitate to contact us at:
www.netartmedia.net/en_Contact.html

Please don't hesitate to check also our other php scripts and 
get an exclusive discount for our professional website systems - 

www.netartmedia.net/en_Products.html